package edu.iu.simplepagerank;

public class PageRankConstants {
	  public static final String NUM_ITERATONS = "num_iterations";
	  public static final String NUM_URLS = "num_urls";
	}