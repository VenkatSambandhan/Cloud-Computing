rm -rf classes
rm statistics.jar
rm -rf output
rm $HADOOP_HOME/bin/statistics.jar 
rm $HADOOP_HOME-standalone/bin/statistics.jar 

