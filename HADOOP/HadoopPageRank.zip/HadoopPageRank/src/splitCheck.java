public class splitCheck {
	public static void main(String[] args){
	String checks = "#2#1";
	String[] arraa = checks.split("#");
	
	for(int i = 0; i < arraa.length ; i++){
		System.out.println("Value" + arraa.length);
	}

	}
}
